//
//  ElectionsView.swift
//  ElectionInfo
//
//  Created by Adam McKnight on 3/5/20.
//  Copyright © 2020 Adam McKnight. All rights reserved.
//

import UIKit

struct pLocations : Codable {
    let pollingLocations : [pLocation]
}
struct pLocation : Codable {
    let address : addr
    let notes: String
    let pollingHours: String
    let sources: [source]
}

struct addr : Codable {
    let locationName : String
    let line1: String
    let city: String
    let state: String
    let zip: String
}

struct source: Codable {
    let name: String
    let official: Bool
}

class ElectionsView: UITableViewController {
    var zip = "null" //use in second api call
    var elections : [election] = []
    var eTitle = ""
    var url = URL(string: "http://api.votesmart.org/Election.getElectionByYearState?key=ffda6850c2f0408aae0d87eb5d8a3e2d&year=2020&stateId=IL")
    var parser : XMLParser! = XMLParser()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        callGoogle()
        callVote()
        
    }
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return elections.count
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return 1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "basic", for: indexPath)

        // Configure the cell...
        cell.textLabel!.text = elections[indexPath.section].name

        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let title = "Elections"
        let message = elections[indexPath.section].date
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okayAction = UIAlertAction(title: "Okay", style: .default, handler: nil)
        alertController.addAction(okayAction)
        present(alertController, animated: true, completion: nil)
        self.tableView.deselectRow(at: indexPath, animated: true)
    }

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func callGoogle() {
        let webAddr  = "https://www.googleapis.com/civicinfo/v2/voterinfo?address=578%20s%20poplar%20street%20manteno%20illinois&electionId=2000&officialOnly=true&fields=pollingLocations&key=AIzaSyA0y-7pLPUtoJME0najH7SFE2fvMnur2xU"
        
        guard let apiURL = URL(string: webAddr) else {return}
        
        URLSession.shared.dataTask(with: apiURL) { (data, response, error) in
            
            if error != nil { print (error!.localizedDescription) }
            
            guard let data = data else { return }
            do
            {
                let response = try JSONDecoder().decode(pLocations.self, from: data)
                DispatchQueue.main.async
                {
                    self.zip = response.pollingLocations[0].address.zip
                }
            }
            catch let jsonError { print(jsonError) }
        }
        .resume()
    }
    
    func callVote() {
        
        let postEndpoint: String = "http://api.votesmart.org/Election.getElectionByYearState?key=ffda6850c2f0408aae0d87eb5d8a3e2d&year=2020&stateId=CA"
        let APIurl = URL(string: postEndpoint)!
        let request = URLRequest(url: APIurl)

        URLSession.shared.dataTask(with: request) {
            ( data,_, error) -> Void in
            
            if error != nil
            {
                print(error!)
                return
            }
            
            guard let data = data else { return }
            let del = XMLParserT()
            del.setData(data: data)
            let x = XMLParser(data: data)
            x.delegate = del
            x.parse()
            self.elections = del.elections
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }.resume()
    }

}
